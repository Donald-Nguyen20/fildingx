# Funtion/help_dialog.py
from PySide6.QtWidgets import QDialog, QHBoxLayout, QListWidget, QTextEdit
from PySide6.QtCore import Qt

try:
    from hud_widgets import qss_hud_metal_header_feel, qss_white_results
except Exception:
    qss_hud_metal_header_feel = None
    qss_white_results = None


class HelpDialog(QDialog):
    """
    User Guide – mở bằng F1
    Không có button, không có menu
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("User Guide")
        self.setGeometry(520, 160, 900, 620)
        self.setModal(True)

        # Apply HUD theme nếu có
        try:
            if qss_hud_metal_header_feel and qss_white_results:
                self.setStyleSheet(
                    qss_hud_metal_header_feel() + qss_white_results()
                )
        except Exception:
            pass

        layout = QHBoxLayout(self)

        # ===== LEFT: TOC =====
        self.toc = QListWidget()
        self.toc.setFixedWidth(300)
        self.toc.setFocusPolicy(Qt.NoFocus)

        # ===== RIGHT: CONTENT =====
        self.viewer = QTextEdit()
        self.viewer.setReadOnly(True)
        self.viewer.setFocusPolicy(Qt.NoFocus)

        layout.addWidget(self.toc)
        layout.addWidget(self.viewer, 1)

        # ===== CONTENT =====
        self.pages = {
            "Overview": self.page_overview(),
            "Search by Name": self.page_search_by_name(),
            "Containers": self.page_containers(),
            "Notes": self.page_notes(),
            "Search Duplicates": self.page_duplicates(),
            "Index Search (SQLite)": self.page_index_search(),
            "Tips & Workflow": self.page_tips(),
        }

        self.toc.addItems(self.pages.keys())
        self.toc.currentTextChanged.connect(self.on_select)
        self.toc.setCurrentRow(0)

    # ================= EVENTS =================
    def on_select(self, key: str):
        self.viewer.setHtml(self.pages.get(key, "<h3>No content</h3>"))

    # ================= PAGES =================
    def page_overview(self) -> str:
        return """
        <h2>File Search & Management</h2>
        <p>Ứng dụng hỗ trợ tìm file kỹ thuật, gom nhóm, ghi chú và tra cứu chỉ mục.</p>
        <ul>
          <li><b>Search by Name</b>: tìm theo tên</li>
          <li><b>Containers</b>: gom file theo nhóm công việc</li>
          <li><b>Notes</b>: ghi chú theo từng file</li>
          <li><b>Duplicates</b>: phát hiện file trùng nội dung</li>
          <li><b>Index Search</b>: tìm theo SQLite index</li>
        </ul>
        <p><b>Phím tắt:</b> F1 – mở User Guide</p>
        """

    def page_search_by_name(self) -> str:
        return """
        <h2>Search by Name</h2>
        <ol>
          <li>Browse folder</li>
          <li>Nhập keyword</li>
          <li>Bấm Search</li>
        </ol>
        <h3>Mẹo nâng cao</h3>
        <ul>
          <li><b>*</b>: tìm A*B hoặc B*A</li>
          <li><b>@keyword</b>: fuzzy + synonyms</li>
          <li><b>$synonym</b>: chỉnh sửa từ đồng nghĩa</li>
        </ul>
        """

    def page_containers(self) -> str:
        return """
        <h2>Containers</h2>
        <ol>
          <li>Nhập tên container → Create</li>
          <li>Chọn file → Add File</li>
          <li>Click container để xem file</li>
        </ol>
        """

    def page_notes(self) -> str:
        return """
        <h2>Notes</h2>
        <ul>
          <li>Click file trong container để mở Notes</li>
          <li>Hỗ trợ text + image</li>
          <li>Lưu dạng HTML</li>
        </ul>
        """

    def page_duplicates(self) -> str:
        return """
        <h2>Search Duplicates</h2>
        <ol>
          <li>Chọn folder</li>
          <li>Bấm Search Duplicates</li>
          <li>Kết quả hiển thị theo GROUP</li>
        </ol>
        <p>Dựa trên <b>nội dung file</b> (size + SHA-256).</p>
        """

    def page_index_search(self) -> str:
        return """
        <h2>Index Search (SQLite)</h2>
        <ol>
          <li>🔍 Contents</li>
          <li>Import DB (*.db)</li>
          <li>Search theo name / content</li>
        </ol>
        """

    def page_tips(self) -> str:
        return """
        <h2>Tips & Workflow</h2>
        <ul>
          <li>Double-click để mở file</li>
          <li>Right-click để mở folder</li>
          <li>Folder lớn → duplicates quét lâu</li>
        </ul>
        """
