from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel,
    QTextBrowser, QLineEdit, QPushButton, QHBoxLayout
)
from PySide6.QtCore import Qt


class AIChatPopup(QDialog):
    def __init__(self, main_app=None, parent=None):
        super().__init__(parent)
        self.main_app = main_app

        self.setWindowTitle("AI Chat")
        self.setFixedSize(460, 400)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(
            "background-color: #f5f5f5;"
            "border: 1px solid #ccc;"
            "border-radius: 10px;"
        )

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("💬 Chat:"))

        self.chat_display = QTextBrowser()
        self.chat_display.setOpenExternalLinks(False)
        self.chat_display.setOpenLinks(False)
        layout.addWidget(self.chat_display)

        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText("Nhập tin nhắn...")
        self.input_line.returnPressed.connect(self.handle_user_input)

        send_btn = QPushButton("Gửi")
        send_btn.clicked.connect(self.handle_user_input)

        input_layout = QHBoxLayout()
        input_layout.addWidget(self.input_line)
        input_layout.addWidget(send_btn)
        layout.addLayout(input_layout)

        # Thông báo trạng thái
        self.chat_display.append("🤖 Trợ lý: RAG đang ở chế độ chờ (chưa load index).")

    def handle_user_input(self):
        user_input = self.input_line.text().strip()
        if not user_input:
            return

        self.chat_display.append(f"🧑 Bạn: {user_input}")
        self.input_line.clear()

        # Tạm thời: stub (sau này bạn thay bằng RAG query)
        self.chat_display.append("🤖 Trợ lý: (stub) Bạn đã gửi câu hỏi. Khi bạn tích hợp RAG query, mình sẽ trả lời theo index.")
